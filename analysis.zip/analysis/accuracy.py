import pandas as pd
import numpy as np


def metric(model,data_params): #prend en argument le np.array des valeurs prédite et le np.array des valeurs réelles (ou des série à définir)
    dataset=data_params['dataset']
    if dataset == "cifar-10" :
        (X_train,y_train),(X_test,y_test)=datasets.cifar10.load_data()
        y_predict=model.predict(y_train)
        categories=['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']
        bool=(y_predict==y_test)
        #corect_pred=bool.sum().values[0] #si les arguments sont des séries
        corect_pred=bool.sum()#si les arguments sont des np.array
        total_pred=bool.shape[0]
    return(corect_pred/total_pred) #renvoie l'accuracy 


dic_y_test={'class':['chien','chat']}
dic_y_predict={'class':['chien','chat']}

df_y_test=[pd.DataFrame(dic_y_test)]
df_y_predict=pd.DataFrame(dic_y_predict)

array_y_test=np.array(['chat','chien'])
array_y_predict=np.array(['chien','chien'])

print(metric(array_y_predict,array_y_test))