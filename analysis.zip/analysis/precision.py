import pandas as pd
import numpy as np
from tensorflow import keras
from keras import layers, datasets, models
import tensorflow as tf

data_params ={}

data_params["dataset"]="cifar-10"
data_params["set"]= "train"
data_params["n"]=  2000

def metric(model,data_params):
    precisions={}
    dataset=data_params['dataset']
    if dataset == "cifar-10" :
        (X_train,y_train),(X_test,y_test)=datasets.cifar10.load_data()
        model.fit(X_train,y_train)
        y_predict=model.predict(y_train)
        categories=['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']
        n=y_predict.shape[0]
        for category in categories:
            total_positive=(y_predict==np.array([category]*n)).sum()
            true_positive=((y_predict==y_test)*(y_predict==np.array([category]*n))).sum() # '*' joue le rôle de and 
            if total_positive!=0:
                precisions[category]=true_positive/total_positive
    return precisions,float(pd.DataFrame.from_dict(precisions, orient='index').mean())

dic_y_test={'class':['chien','chat']}
dic_y_predict={'class':['chien','chat']}

df_y_test=[pd.DataFrame(dic_y_test)]
df_y_predict=pd.DataFrame(dic_y_predict)

array_y_test=np.array(['chat','chien','chat'])
array_y_predict=np.array(['chien','chien','chat'])

print(metric(model,data_params))
