import pandas as pd
import numpy as np

def metric(model,data_params):
    recalls={}
    dataset=data_params['dataset']
    if dataset == "cifar-10" :
        (X_train,y_train),(X_test,y_test)=datasets.cifar10.load_data()
        y_predict=model.predict(y_train)
        categories=['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']
        n=y_predict.shape[0]
        for category in categories:
            true_positive=((y_predict==y_test) * (y_predict==np.array([category]*n))).sum()
            false_negative=((y_predict!=y_test) * (y_predict!=np.array([category]*n))).sum()
            if true_positive+false_negative!=0:
                recalls[category]=true_positive/(true_positive+false_negative)
    return (recalls,float(pd.DataFrame.from_dict(recalls, orient='index').mean())) #moyenne des recall sur chaque categorie 

dic_y_test={'class':['chien','chat']}
dic_y_predict={'class':['chien','chat']}

df_y_test=[pd.DataFrame(dic_y_test)]
df_y_predict=pd.DataFrame(dic_y_predict)

array_y_test=np.array(['chat','chien'])
array_y_predict=np.array(['chien','chien'])

print(metric(array_y_predict,array_y_test,['chat','chien']))
